//
//  ViewController.swift
//  help
//
//  Created by Vladimir Sinkevich on 03.05.2023.
//

import UIKit

class ViewController: UIViewController {
    lazy var quadrateView = View()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        quadrateView.layer.cornerRadius = 8
        // Do any additional setup after loading the view.
        view.addSubview(quadrateView)
        
    }
    
    override func viewDidLayoutSubviews() {
            super.viewDidLayoutSubviews()
            
            quadrateView.frame = .init(x: 100, y: quadrateView.frame.origin.y, width: 105, height: 105)
            quadrateView.center.y = view.frame.height / 2
        }
    
    
}
    class View: UIView {
        let gradientLayer = CAGradientLayer()
        init() {
        super.init(frame: .zero)
            backgroundColor = .red
            layer.cornerCurve = .continuous
            layer.shadowOpacity = 0.7
            layer.shadowColor = UIColor.blue.cgColor
            layer.shadowOffset = CGSize(width: .zero, height: 10)
            layer.shadowRadius = 10
            gradientLayer.startPoint = .init(x: 0, y: 0)
            gradientLayer.endPoint = .init(x: 1, y: 0.5)
            gradientLayer.colors = [UIColor.blue.cgColor, UIColor.red.cgColor]
            layer.addSublayer(gradientLayer)
        }
        
        required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        
        override func layoutSublayers(of layer: CALayer) {
                super.layoutSublayers(of: layer)
                if layer == self.layer {
                    gradientLayer.frame = bounds
                    gradientLayer.cornerRadius = layer.cornerRadius
                }
            }
    }
    

    
    


